import Link from "next/link"
import { BookOpen, ShoppingBag, Sparkles, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardBody } from "@/components/ui/card"

const quickLinks = [
  {
    href: "/draw",
    label: "เริ่มดูดวง",
    description: "ตอบคำถาม 3 ข้อเพื่อเปิดคำทำนายและรับคำแนะนำเฉพาะตัว",
    icon: Sparkles,
  },
  {
    href: "/shop",
    label: "เข้าร้านมู",
    description: "ดูสินค้า เพิ่มลงตะกร้า และเลือกซื้อได้ทั้งแบบปกติและจากผลดูดวง",
    icon: ShoppingBag,
  },
  {
    href: "/fate-history",
    label: "ประวัติดวง",
    description: "ย้อนดูผลลัพธ์ที่ผ่านมาและกลับไปเลือกสินค้าที่เหมาะกับแต่ละผลได้อีกครั้ง",
    icon: BookOpen,
  },
]

const highlights = [
  {
    title: "Fortune Flow",
    copy: "จากคำถามสั้น ๆ ไปสู่คำทำนาย ผลลัพธ์ และสินค้าแนะนำใน flow เดียว",
  },
  {
    title: "Mystic Shop",
    copy: "มีหน้าร้าน, รายละเอียดสินค้า, ตะกร้า, checkout และการชำระเงินครบสำหรับเดโม่",
  },
  {
    title: "Admin Ready",
    copy: "แอดมินดู dashboard, ตรวจสลิป, อัปเดตสถานะออเดอร์ และจัดการสินค้าได้แล้ว",
  },
]

export default function Home() {
  return (
    <main className="min-h-screen star-bg">
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-14 sm:py-20">
        <div className="grid lg:grid-cols-[1.2fr_0.8fr] gap-8 items-start">
          <Card className="p-8 sm:p-10" glow>
            <CardBody className="p-0">
              <div className="inline-flex items-center gap-2 mystic-badge bg-gold/10 text-gold border-gold/30 mb-5">
                <Star className="w-4 h-4" />
                FLORDER EXPERIENCE
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold leading-tight text-foreground">
                Fortune and Flow
              </h1>

              <p className="mt-5 text-base sm:text-lg text-muted-foreground font-body max-w-2xl">
                ระบบดูดวงและร้านสินค้าที่เชื่อมผลคำทำนายเข้ากับประสบการณ์ซื้อของใน flow
                เดียว ตั้งแต่เริ่มดูดวง เลือกสินค้า ชำระเงิน ไปจนถึงติดตามออเดอร์
              </p>

              <div className="flex flex-wrap gap-3 mt-8">
                <Link href="/draw">
                  <Button size="lg">
                    <Sparkles className="w-4 h-4" />
                    Start Draw
                  </Button>
                </Link>
                <Link href="/shop">
                  <Button size="lg" variant="gold">
                    <ShoppingBag className="w-4 h-4" />
                    Open Shop
                  </Button>
                </Link>
              </div>

              <div className="grid sm:grid-cols-3 gap-4 mt-10">
                {highlights.map((item) => (
                  <div
                    key={item.title}
                    className="rounded-2xl border border-border bg-secondary/35 p-4"
                  >
                    <div className="text-sm font-semibold text-gold font-body">
                      {item.title}
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground font-body leading-6">
                      {item.copy}
                    </p>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>

          <div className="grid gap-5">
            <Card className="p-6">
              <CardBody className="p-0">
                <div className="text-xs tracking-[0.18em] text-gold font-body">LIVE FLOW</div>
                <div className="mt-3 flex flex-col gap-3">
                  <FlowStep step="1" title="Draw" copy="ตอบคำถาม เปิดทางเลือกคำทำนาย" />
                  <FlowStep step="2" title="Choose" copy="เลือกผลลัพธ์ที่อยากรับจากโชคชะตา" />
                  <FlowStep step="3" title="Shop" copy="ดูสินค้าแนะนำหรือซื้อผ่านร้านได้ทันที" />
                  <FlowStep step="4" title="Checkout" copy="ชำระผ่านบัตรเครดิตหรือ PromptPay" />
                </div>
              </CardBody>
            </Card>

            <Card className="p-6">
              <CardBody className="p-0">
                <div className="text-xs tracking-[0.18em] text-gold font-body">QUICK ACCESS</div>
                <div className="grid gap-3 mt-4">
                  {quickLinks.map((item) => {
                    const Icon = item.icon

                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        className="rounded-2xl border border-border bg-secondary/30 p-4 hover:border-primary/50 transition-colors no-underline"
                      >
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 rounded-xl bg-primary/20 border border-primary/40 flex items-center justify-center text-accent">
                            <Icon className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="font-serif text-lg text-foreground">{item.label}</div>
                            <p className="mt-1 text-sm text-muted-foreground font-body leading-6">
                              {item.description}
                            </p>
                          </div>
                        </div>
                      </Link>
                    )
                  })}
                </div>
              </CardBody>
            </Card>
          </div>
        </div>

        <section className="mt-10 grid lg:grid-cols-3 gap-5">
          <DemoCard
            title="User Journey"
            copy="สมัครสมาชิก ดูดวง เลือกสินค้า เพิ่มลงตะกร้า ชำระเงิน และกลับมาดูออเดอร์ได้ครบ"
            href="/orders"
            cta="View Orders"
          />
          <DemoCard
            title="Mystic Archive"
            copy="ประวัติผลดูดวงช่วยให้ย้อนกลับไปดูคำทำนายเดิมและซื้อสินค้าจากผลก่อนหน้าได้"
            href="/fate-history"
            cta="Open History"
          />
          <DemoCard
            title="Admin Workspace"
            copy="แอดมินตรวจสลิป อัปเดตสถานะ และจัดการสินค้าได้จากหลังบ้านในหน้าเดียว"
            href="/admin"
            cta="Open Admin"
          />
        </section>
      </section>
    </main>
  )
}

function FlowStep({
  step,
  title,
  copy,
}: {
  step: string
  title: string
  copy: string
}) {
  return (
    <div className="flex items-start gap-3 rounded-2xl border border-border bg-background/30 p-3">
      <div className="w-8 h-8 rounded-full bg-accent/20 border border-accent/40 flex items-center justify-center text-accent text-sm font-semibold font-body">
        {step}
      </div>
      <div>
        <div className="text-foreground font-semibold font-body">{title}</div>
        <p className="text-sm text-muted-foreground font-body mt-1 leading-6">{copy}</p>
      </div>
    </div>
  )
}

function DemoCard({
  title,
  copy,
  href,
  cta,
}: {
  title: string
  copy: string
  href: string
  cta: string
}) {
  return (
    <Card className="p-6">
      <CardBody className="p-0 flex flex-col h-full">
        <h2 className="text-2xl font-serif font-semibold text-foreground">{title}</h2>
        <p className="mt-3 text-sm text-muted-foreground font-body leading-6 flex-1">{copy}</p>
        <Link href={href} className="mt-5 inline-flex">
          <Button variant="secondary">{cta}</Button>
        </Link>
      </CardBody>
    </Card>
  )
}
